# ...

- ...

# Prática com Vue.js

...

## Criando um projeto Exemplo na plataforma online CodeSandBox.io

...

## Estrutura de um componente Vue.js (HTML/JS/CSS)

- Componentização: Importação, Registro e Uso do COmponente

## Criando e importando um componente

...

## Vue.Router (Configuração Básica)

...

## Comunicação entre Componentes

...

## Instalação de Dependências

...

### Bootstrap

npm i bootstrap jquery popper.js
Add to src/main.js:

import 'bootstrap';
import 'bootstrap/dist/css/bootstrap.min.css';
