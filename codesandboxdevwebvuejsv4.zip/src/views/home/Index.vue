<template>
  <SimpleLayoutPage>
    <div class="home">
      <h1>{{ info }}</h1>
      <img src="../../assets/logo.png">
      <img src="/static/profile.jpg">
      <br>
      <router-link to="/about">
        <span>About me</span>
      </router-link>
      <br>
      <router-link :to="{name: 'About'}">
        <span>About me</span>
      </router-link>
      <br>
      <a href="#" @click="AboutMe">About me</a>
    </div>
  </SimpleLayoutPage>
</template>

<script>
import SimpleLayoutPage from "@/layouts/SimpleLayout";
export default {
  components: {
    SimpleLayoutPage
  },
  data() {
    return {
      info: "Home",
      ages: [1, 2, 3]
    };
  },
  methods: {
    AboutMe: function() {
      this.$router.push("/about");
    }
  }
};
</script>

<style scoped>
.home {
  font-family: "Avenir", Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
}

.home img {
  height: 100px;
}
</style>